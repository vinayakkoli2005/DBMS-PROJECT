-- 1. Shelter Table
CREATE TABLE Shelter (
    ShelterID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Location VARCHAR(255) NOT NULL,
    Capacity INT CHECK (Capacity >= 0),
    ContactInfo VARCHAR(100) NOT NULL
);

-- 2. Animal Table (References Shelter)
CREATE TABLE Animal (
    AnimalID SERIAL PRIMARY KEY,
    Name VARCHAR(100),
    Species VARCHAR(50) NOT NULL,
    Breed VARCHAR(100),
    Age INT CHECK (Age >= 0),
    Gender VARCHAR(10) CHECK (Gender IN ('Male', 'Female', 'Unknown')),
    MedicalCondition TEXT,
    ShelterID INT REFERENCES Shelter(ShelterID) ON DELETE SET NULL,
    Status VARCHAR(50) CHECK (Status IN ('Available', 'Adopted', 'Medical Care', 'Quarantined'))
);

-- 3. Veterinarian Table
CREATE TABLE Veterinarian (
    VetID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Clinic VARCHAR(255) NOT NULL,
    ContactInfo VARCHAR(100) NOT NULL UNIQUE,
    Specialization VARCHAR(255)
);

-- 4. Rescue Team Table
CREATE TABLE RescueTeam (
    TeamID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    ContactNumber VARCHAR(15) NOT NULL UNIQUE,
    AssignedArea VARCHAR(255) NOT NULL
);

-- 5. Rescue Report Table
CREATE TABLE RescueReport (
    ReportID SERIAL PRIMARY KEY,
    ReporterName VARCHAR(100) NOT NULL,
    Location VARCHAR(255) NOT NULL,
    Urgency VARCHAR(20) CHECK (Urgency IN ('Low', 'Medium', 'High')),
    Status VARCHAR(50) CHECK (Status IN ('Pending', 'Ongoing', 'Resolved'))
);

-- 6. Found Report Table
CREATE TABLE FoundReport (
    FoundReportID SERIAL PRIMARY KEY,
    AnimalDetails TEXT NOT NULL,
    Contact VARCHAR(15) NOT NULL
);

-- 7. Adopter Table
CREATE TABLE Adopter (
    AdopterID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Address TEXT NOT NULL,
    Phone VARCHAR(15) NOT NULL UNIQUE,
    Email VARCHAR(100) UNIQUE,
    HomeEnvironment TEXT,
    FinancialStatus TEXT
);

-- 8. Staff Member Table (References Shelter)
CREATE TABLE StaffMember (
    StaffID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Role VARCHAR(50),
    ContactInfo VARCHAR(100) NOT NULL UNIQUE,
    AssignedShelterID INT REFERENCES Shelter(ShelterID) ON DELETE SET NULL
);

-- 9. Medical Record Table (References Animal, Veterinarian)
CREATE TABLE MedicalRecord (
    RecordID SERIAL PRIMARY KEY,
    AnimalID INT REFERENCES Animal(AnimalID) ON DELETE CASCADE,
    Treatment TEXT NOT NULL,
    VaccinationDate DATE,
    SurgeryDetails TEXT,
    NextCheckupDate DATE,
    VetID INT REFERENCES Veterinarian(VetID) ON DELETE SET NULL
);

-- 10. License Table (References Animal)
CREATE TABLE License (
    LicenseID SERIAL PRIMARY KEY,
    OwnerName VARCHAR(100) NOT NULL,
    AnimalID INT REFERENCES Animal(AnimalID) ON DELETE CASCADE,
    IssueDate DATE NOT NULL,
    ExpiryDate DATE NOT NULL,
    Status VARCHAR(50) CHECK (Status IN ('Valid', 'Expired', 'Revoked')),
    Field TEXT
);

-- 11. Adoption Table (References Animal, Adopter)
CREATE TABLE Adoption (
    AdoptionID SERIAL PRIMARY KEY,
    AnimalID INT REFERENCES Animal(AnimalID) ON DELETE CASCADE,
    AdopterID INT REFERENCES Adopter(AdopterID) ON DELETE CASCADE,
    AdoptionDate DATE NOT NULL DEFAULT CURRENT_DATE,
    Status VARCHAR(50) CHECK (Status IN ('Pending', 'Approved', 'Rejected')),
    FollowUpDate DATE
);

-- 12. Task Table (References Staff)
CREATE TABLE Task (
    TaskID SERIAL PRIMARY KEY,
    Description TEXT NOT NULL,
    TaskDate DATE NOT NULL DEFAULT CURRENT_DATE,
    StaffID INT
);

-- 13. Donation Table (References Shelter)
CREATE TABLE Donation (
    DonationID SERIAL PRIMARY KEY,
    DonorName VARCHAR(100) NOT NULL,
    Amount DECIMAL(10,2) CHECK (Amount > 0),
    Date DATE NOT NULL DEFAULT CURRENT_DATE,
    ShelterID INT REFERENCES Shelter(ShelterID) ON DELETE SET NULL
);



