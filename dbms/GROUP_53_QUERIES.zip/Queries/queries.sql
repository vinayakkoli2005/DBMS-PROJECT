-- 1. Find all animals available for adoption
SELECT * FROM Animal WHERE Status = 'Available';

-- 2. Get the total number of animals in each shelter
SELECT ShelterID, COUNT(*) AS TotalAnimals
FROM Animal
GROUP BY ShelterID;

-- 3. List all staff members working at a specific shelter (JOIN)
SELECT s.StaffID, s.Name, s.Role, s.ContactInfo, sh.Name AS ShelterName 
FROM StaffMember s
JOIN Shelter sh ON s.AssignedShelterID = sh.ShelterID
WHERE sh.ShelterID = <ShelterID>; -- Replace <ShelterID> with the specific ID

-- 4. Find all animals treated by a specific veterinarian (JOIN)
SELECT a.AnimalID, a.Name, a.Species, v.Name AS VeterinarianName, m.Treatment
FROM MedicalRecord m
JOIN Animal a ON m.AnimalID = a.AnimalID
JOIN Veterinarian v ON m.VetID = v.VetID
WHERE v.VetID = <VetID>; -- Replace <VetID> with the specific veterinarian ID

-- 5. Find all adopters who have adopted more than one animal (GROUP BY)
SELECT a.AdopterID, a.Name, COUNT(ad.AnimalID) AS TotalAdoptions
FROM Adoption ad
JOIN Adopter a ON ad.AdopterID = a.AdopterID
WHERE ad.Status = 'Approved'
GROUP BY a.AdopterID, a.Name
HAVING COUNT(ad.AnimalID) > 1;

-- 6. Find the total donation amount received by each shelter (Aggregation + GROUP BY)
SELECT s.ShelterID, s.Name, COALESCE(SUM(d.Amount), 0) AS TotalDonations
FROM Shelter s
LEFT JOIN Donation d ON s.ShelterID = d.ShelterID
GROUP BY s.ShelterID, s.Name;

-- 7. Find all rescue reports with urgent cases and their assigned teams (JOIN + Filtering)
SELECT r.ReportID, r.ReporterName, r.Location, r.Urgency, r.Status, rt.Name AS TeamName
FROM RescueReport r
JOIN RescueTeam rt ON r.Location = rt.AssignedArea
WHERE r.Urgency = 'High';

-- 8. Find all animals in shelters with an occupancy rate above 75% (Subquery)
SELECT a.*
FROM Animal a
WHERE a.ShelterID IN (
    SELECT s.ShelterID
    FROM Shelter s
    JOIN (
        SELECT ShelterID, COUNT(*) AS CurrentOccupancy
        FROM Animal
        GROUP BY ShelterID
    ) AS Occupancy ON s.ShelterID = Occupancy.ShelterID
    WHERE (Occupancy.CurrentOccupancy * 100.0 / s.Capacity) > 75
);

-- 9. Find the most frequently adopted animal species (Aggregate + Subquery)
SELECT Species, COUNT(*) AS AdoptionCount
FROM Animal
WHERE AnimalID IN (SELECT AnimalID FROM Adoption WHERE Status = 'Approved')
GROUP BY Species
ORDER BY AdoptionCount DESC
LIMIT 2;

-- 10. Find all staff members who have not been assigned any tasks (LEFT JOIN + Filtering)
SELECT s.StaffID, s.Name, s.Role, s.ContactInfo, sh.Name AS ShelterName
FROM StaffMember s
LEFT JOIN Task t ON s.StaffID = t.StaffID
LEFT JOIN Shelter sh ON s.AssignedShelterID = sh.ShelterID
WHERE t.TaskID IS NULL;
