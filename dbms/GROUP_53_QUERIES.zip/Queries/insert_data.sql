-- Insert into RescueTeam
INSERT INTO RescueTeam (Name, ContactNumber, AssignedArea) VALUES
('Alpha Squad', '9876543210', 'Downtown'),
('Bravo Team', '9123456789', 'Uptown'),
('Charlie Rescue', '8234567891', 'City Center'),
('Delta Force', '7567894321', 'Suburbs'),
('Echo Squad', '6789012345', 'Rural Area');

-- Insert into RescueReport
INSERT INTO RescueReport (ReporterName, Location, Urgency, Status) VALUES
('John Doe', 'Downtown', 'High', 'Pending'),
('Jane Smith', 'Uptown', 'Medium', 'Ongoing'),
('Alice Johnson', 'City Center', 'Low', 'Resolved'),
('Bob Williams', 'Suburbs', 'High', 'Pending'),
('Charlie Brown', 'Rural Area', 'Medium', 'Ongoing');

-- Insert into FoundReport
INSERT INTO FoundReport (AnimalDetails, Contact) VALUES
('Brown Labrador, injured leg', '9876543210'),
('White Cat, lost', '9123456789'),
('Parrot, found in park', '8234567891'),
('Black Dog, looks hungry', '7567894321'),
('Rabbit, wandering near school', '6789012345');

-- Insert into Shelter
INSERT INTO Shelter (Name, Location, Capacity, ContactInfo) VALUES
('Happy Paws Shelter', 'Downtown', 6, '9876543210'),
('Safe Haven', 'Uptown', 6, '9123456789'),
('Hope for Paws', 'City Center', 6, '8234567891'),
('Animal Rescue Home', 'Suburbs', 6, '7567894321'),
('Forever Home Shelter', 'Rural Area', 6, '6789012345');

-- Insert into Animal
INSERT INTO Animal (Name, Species, Breed, Age, Gender, MedicalCondition, ShelterID, Status) VALUES
('Buddy', 'Dog', 'Labrador', 3, 'Male', 'Injured leg', 1, 'Medical Care'),
('Whiskers', 'Cat', 'Persian', 2, 'Female', 'Healthy', 2, 'Available'),
('Polly', 'Bird', 'Parrot', 1, 'Male', 'Wing injury', 3, 'Medical Care'),
('Max', 'Dog', 'Beagle', 4, 'Male', 'Minor infection', 1, 'Available'),
('Cocoa', 'Rabbit', 'Dutch', 2, 'Female', 'Healthy', 5, 'Adopted'),
('Rocky', 'Dog', 'Golden Retriever', 5, 'Male', 'Healthy', 1, 'Available'),
('Mittens', 'Cat', 'Siamese', 3, 'Female', 'Minor cold', 2, 'Medical Care'),
('Sunny', 'Bird', 'Canary', 2, 'Male', 'Healthy', 3, 'Available'),
('Bailey', 'Dog', 'Bulldog', 4, 'Female', 'Ear infection', 1, 'Medical Care'),
('Thumper', 'Rabbit', 'Lionhead', 1, 'Male', 'Healthy', 5, 'Available'),
('Daisy', 'Dog', 'Cocker Spaniel', 6, 'Female', 'Arthritis', 1, 'Medical Care'),
('Simba', 'Cat', 'Maine Coon', 5, 'Male', 'Healthy', 2, 'Available'),
('Chirpy', 'Bird', 'Finch', 1, 'Female', 'Injured wing', 3, 'Medical Care'),
('Bruno', 'Dog', 'Doberman', 3, 'Male', 'Healthy', 1, 'Available'),
('Floppy', 'Rabbit', 'Holland Lop', 2, 'Female', 'Minor infection', 5, 'Medical Care');

-- Insert Veterinarians 
INSERT INTO Veterinarian (Name, Clinic, ContactInfo, Specialization) VALUES
('Dr. Sarah Green', 'City Vet Clinic', '9876543210', 'Dogs'),
('Dr. James Brown', 'Uptown Animal Hospital', '9123456789', 'Cats'),
('Dr. Emily White', 'Hope Vet Center', '8234567891', 'Exotic Animals'),
('Dr. Robert King', 'Paw Care Clinic', '7567894321', 'Birds'),
('Dr. Anna Taylor', 'Animal Wellness Center', '6789012345', 'General'),
('Dr. Michael Adams', 'Rabbit Care Center', '7890123456', 'Rabbits'),  
('Dr. Olivia Scott', 'Wildlife Healing Center', '8901234567', 'Wild Animals'); 

-- Insert into MedicalRecord
INSERT INTO MedicalRecord (AnimalID, Treatment, VaccinationDate, SurgeryDetails, NextCheckupDate, VetID) VALUES
(1, 'Leg bandaged, antibiotics', '2024-02-01', 'None', '2024-03-01', 1),
(3, 'Wing healing treatment', '2024-01-20', 'None', '2024-02-20', 4),
(4, 'Deworming and minor infection treatment', '2024-02-05', 'None', '2024-03-05', 1),
(6, 'Fractured paw treated', '2024-01-10', 'Minor surgery', '2024-02-10', 1),
(7, 'Ear infection treated', '2024-02-15', 'None', '2024-03-15', 2),
(8, 'Broken beak treatment', '2024-01-05', 'None', '2024-02-05', 4),
(10, 'Spaying surgery', '2024-01-20', 'Successful spay operation', '2024-02-20', 6),
(12, 'Dental cleaning', '2024-01-18', 'None', '2024-02-18', 2),
(15, 'Minor wound care', '2024-02-05', 'None', '2024-03-05', 6);

-- Insert into Adopter
INSERT INTO Adopter (Name, Address, Phone, Email, HomeEnvironment, FinancialStatus) VALUES
('Michael Johnson', '123 Main St', '9876543210', 'michael@example.com', 'Spacious house with garden', 'Stable income'),
('Linda Wilson', '456 Oak St', '9123456789', 'linda@example.com', 'Apartment with pet-friendly area', 'Good savings'),
('David Smith', '789 Pine St', '8234567891', 'david@example.com', 'Owns a farm', 'Excellent financial condition'),
('Jessica Brown', '101 Elm St', '7567894321', 'jessica@example.com', 'Shared apartment', 'Moderate income'),
('Daniel White', '202 Maple St', '6789012345', 'daniel@example.com', 'Spacious home with backyard', 'Stable income');

-- Insert into License
INSERT INTO License (OwnerName, AnimalID, IssueDate, ExpiryDate, Status, Field) VALUES
('Michael Johnson', 5, '2024-01-01', '2025-01-01', 'Valid', 'Dog Adoption'),
('Linda Wilson', 2, '2024-02-05', '2025-02-05', 'Valid', 'Cat Ownership'),
('David Smith', 1, '2024-01-10', '2025-01-10', 'Valid', 'Dog Adoption'),
('Jessica Brown', 4, '2024-02-15', '2025-02-15', 'Valid', 'Rabbit Care'),
('Daniel White', 3, '2024-01-20', '2025-01-20', 'Valid', 'Bird Adoption');

-- Insert into StaffMember
INSERT INTO StaffMember (Name, Role, ContactInfo, AssignedShelterID) VALUES
('Emma Watson', 'Shelter Manager', '9876543210', 1),
('John Doe', 'Veterinary Assistant', '9123456789', 2),
('Samantha Green', 'Animal Caretaker', '8234567891', 3),
('Robert Lee', 'Adoption Coordinator', '7567894321', 4),
('Emily Davis', 'Operations Head', '6789012345', 5),
('Daniel Brown', 'Animal Caretaker', '8765432109', 1),
('Sophia Martinez', 'Veterinarian', '8123456790', 2),
('Liam Johnson', 'Shelter Manager', '8345678901', 3),
('Ava White', 'Animal Trainer', '7456789012', 4),
('Noah Wilson', 'Veterinary Assistant', '6987654321', 5),
('Olivia Harris', 'Operations Coordinator', '7890123456', 1),
('William Clark', 'Adoption Coordinator', '8901234567', 2),
('Charlotte Lewis', 'Animal Welfare Officer', '9012345678', 3),
('James Hall', 'Shelter Manager', '6789234567', 4),
('Isabella Allen', 'Animal Caretaker', '5678901234', 5);


-- Insert into Donation
INSERT INTO Donation (DonorName, Amount, Date, ShelterID) VALUES
('Olivia Martinez', 500, '2024-02-01', 1),
('James Anderson', 300, '2024-01-15', 2),
('Sophia Thompson', 700, '2024-01-25', 3),
('William Roberts', 450, '2024-02-10', 4),
('Emma Johnson', 600, '2024-02-05', 5);

-- Insert into Adoption
INSERT INTO Adoption (AnimalID, AdopterID, AdoptionDate, Status, FollowUpDate) VALUES
(5, 1, '2024-02-01', 'Approved', '2024-03-01'),
(1, 3, '2024-02-10', 'Pending', '2024-03-10'),
(4, 4, '2024-02-15', 'Rejected', NULL),
(3, 5, '2024-02-20', 'Approved', '2024-03-20'),
(8, 1, '2024-02-01', 'Approved', '2024-03-01'),
(11, 2, '2024-02-18', 'Rejected', NULL),
(7, 4, '2024-02-15', 'Rejected', NULL),
(9, 4, '2024-02-20', 'Approved', '2024-03-20'),
(14, 5, '2024-02-20', 'Approved', '2024-03-20');


-- Insert into Task
INSERT INTO Task (Description, TaskDate, StaffID) VALUES
('Feed and clean animal enclosures', '2024-02-01', 1),
('Assist in medical checkups', '2024-02-02', 2),
('Organize adoption event', '2024-02-03', 3),
('Conduct Shelter maintenance', '2024-02-04', 4),
('Prepare reports on rescued animals', '2024-02-05', 5);
