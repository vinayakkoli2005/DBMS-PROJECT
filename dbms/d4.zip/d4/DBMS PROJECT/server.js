// server.js
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const port = 3000;

// Middleware
app.use(cors());

// PostgreSQL connection
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'project2',
  password: '1234',
  port: 5432,
});

// Route to fetch available animals
app.get('/available-animals', async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Animal WHERE Status = 'Available'");
    res.json(result.rows);
  } catch (err) {
    console.error('Error executing query', err.stack);
    res.status(500).send('Error fetching data');
  }
});

app.get('/get-shelter-counts', async (req, res) => {
    try {
      const result = await pool.query('SELECT ShelterID, COUNT(*) AS TotalAnimals FROM Animal GROUP BY ShelterID');
      res.json(result.rows); // Send the result as JSON
    } catch (err) {
      console.error('Error executing query', err.stack);
      res.status(500).send('Error executing query');
    }
  });

app.get('/staff-in-shelter/:shelterId', async (req, res) => {
    const shelterId = req.params.shelterId;
  
    try {
      const result = await pool.query(
        `SELECT s.StaffID, s.Name, s.Role, s.ContactInfo, sh.Name AS ShelterName
         FROM StaffMember s
         JOIN Shelter sh ON s.AssignedShelterID = sh.ShelterID
         WHERE sh.ShelterID = $1`,
        [shelterId]
      );
  
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching staff:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

app.get('/animals-treated/:vetId', async (req, res) => {
    const vetId = req.params.vetId;
  
    try {
      const result = await pool.query(
        `SELECT a.AnimalID, a.Name, a.Species, v.Name AS VeterinarianName, m.Treatment
         FROM MedicalRecord m
         JOIN Animal a ON m.AnimalID = a.AnimalID
         JOIN Veterinarian v ON m.VetID = v.VetID
         WHERE v.VetID = $1`,
        [vetId]
      );
  
      res.json(result.rows);
    } catch (err) {
      console.error('Error fetching treated animals:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
app.get('/frequent-adopters', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT a.AdopterID, a.Name, COUNT(ad.AnimalID) AS TotalAdoptions
      FROM Adoption ad
      JOIN Adopter a ON ad.AdopterID = a.AdopterID
      WHERE ad.Status = 'Approved'
      GROUP BY a.AdopterID, a.Name
      HAVING COUNT(ad.AnimalID) > 1
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching frequent adopters:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
//6
app.get("/total-donations", async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT s.ShelterID, s.Name, COALESCE(SUM(d.Amount), 0) AS TotalDonations
        FROM Shelter s
        LEFT JOIN Donation d ON s.ShelterID = d.ShelterID
        GROUP BY s.ShelterID, s.Name
      `);
  
      res.json(result.rows);
    } catch (err) {
      console.error("Error fetching total donations:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
//7
app.get("/urgent-reports", async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT r.ReportID, r.ReporterName, r.Location, r.Urgency, r.Status, rt.Name AS TeamName
        FROM RescueReport r
        JOIN RescueTeam rt ON r.Location = rt.AssignedArea
        WHERE r.Urgency = 'High'
      `);
  
      res.json(result.rows);
    } catch (err) {
      console.error("Error fetching urgent reports:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
  
//8
app.get("/overcrowded-animals", async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT a.*
        FROM Animal a
        WHERE a.ShelterID IN (
          SELECT s.ShelterID
          FROM Shelter s
          JOIN (
            SELECT ShelterID, COUNT(*) AS CurrentOccupancy
            FROM Animal
            GROUP BY ShelterID
          ) AS Occupancy ON s.ShelterID = Occupancy.ShelterID
          WHERE (Occupancy.CurrentOccupancy * 100.0 / s.Capacity) > 75
        )
      `);
  
      res.json(result.rows);
    } catch (err) {
      console.error("Error fetching overcrowded animal data:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

//9
app.get("/popular-species", async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT Species, COUNT(*) AS AdoptionCount
        FROM Animal
        WHERE AnimalID IN (SELECT AnimalID FROM Adoption WHERE Status = 'Approved')
        GROUP BY Species
        ORDER BY AdoptionCount DESC
        LIMIT 2
      `);
  
      res.json(result.rows);
    } catch (err) {
      console.error("Error fetching popular species data:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  app.get("/idle-staff", async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT s.StaffID, s.Name, s.Role, s.ContactInfo, sh.Name AS ShelterName
        FROM StaffMember s
        LEFT JOIN Task t ON s.StaffID = t.StaffID
        LEFT JOIN Shelter sh ON s.AssignedShelterID = sh.ShelterID
        WHERE t.TaskID IS NULL;
      `);
  
      res.json(result.rows);
    } catch (err) {
      console.error("Error fetching staff data:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
  
  
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
